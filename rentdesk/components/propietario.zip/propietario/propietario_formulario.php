<?php
include("models/propietario_formulario.php");
include("views/propietario_formulario.php");
